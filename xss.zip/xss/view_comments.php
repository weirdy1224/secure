
<?php
include 'config.php';
$sql = "SELECT username, comment, created_at FROM comments ORDER BY created_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self';">
    <title>View Comments</title>
</head>
<body>
    <h2>Comments</h2>
    <?php
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "<p><strong>" . $row['username'] . ":</strong> " . $row['comment'] . " <em>at " . $row['created_at'] . "</em></p>";
            //to make the code secure, replace the above line with “echo "<p><strong>" . htmlspecialchars($row['username']) . ":</strong> " . htmlspecialchars($row['comment']) . " <em>at " . $row['created_at'] . "</em></p>";"
        }
    } else {
        echo "No comments yet.";
    }
    $conn->close();
    ?>
</body>
</html>